# Wave Rush — versión optimizada

Este repositorio contiene el código web recuperado del APK que compartiste y la configuración para volver a compilarlo como APK Android mediante GitHub Actions.

## Mejoras de rendimiento incluidas
- Física de 240 Hz reducida a 120 Hz para disminuir el trabajo de CPU por segundo.
- Resolución interna del canvas limitada a 1,5× la densidad de pantalla para reducir el coste de dibujo en móviles.
- Límite de puntos de la estela reducido de 600 a 240.
- Menos partículas al morir para reducir picos de renderizado.

Estas modificaciones buscan reducir tirones; el resultado depende del móvil y de la carga del sistema.

## Compilar con GitHub desde el móvil
1. Descomprime este ZIP.
2. Crea un repositorio nuevo en GitHub y sube **todo el contenido** de esta carpeta (no la carpeta contenedora).
3. Abre la pestaña **Actions** del repositorio.
4. Selecciona **Compilar APK Android** y pulsa **Run workflow**. También se compila al subir cambios a `main` o `master`.
5. Cuando termine, abre la ejecución y descarga el artefacto **WaveRush-APK**. Dentro estará `app-debug.apk`.

## Importante
El ZIP original solo contenía `app-debug.apk`, no el proyecto Android/Gradle original. Por eso este paquete reconstruye el proyecto a partir de la aplicación web incluida dentro del APK y genera una envoltura Android nueva con Capacitor. No es una modificación binaria directa del APK original y puede diferir en permisos, identificador de aplicación o comportamiento nativo.
